<section class="empty-state-section">
    <div class="empty-state-row">
        <h2>Nothing to show here</h2>
        <p>It looks as though there is no content added to this page yet.</p>
    </div>
</section>